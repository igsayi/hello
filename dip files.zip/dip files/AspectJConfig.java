/*******************************************************************************
 * Licensed materials - Property of IBM
 * 6949-63D
 * Developed by Digital Integration Practice
 * (C) Copyright IBM Corp. 2016 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
 * This asset is provided ``as is'' and any expressed or implied warranties, including, but not limited to, the implied warranties and fitness 
 * for a particular purpose are disclaimed. in no event shall IBM be liable for any direct, indirect, incidental, special, 
 * exemplary, or consequential damages.
 * 
 *******************************************************************************/
package com.ibm.dip.microservice.framework.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableLoadTimeWeaving;
import org.springframework.context.annotation.EnableLoadTimeWeaving.AspectJWeaving;
import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;

@Configuration
@EnableLoadTimeWeaving(aspectjWeaving = AspectJWeaving.ENABLED)
public class AspectJConfig {
	
	@Bean
	public InstrumentationLoadTimeWeaver loadTimeWeaver() {
		return new InstrumentationLoadTimeWeaver();
	    
	}
	
}