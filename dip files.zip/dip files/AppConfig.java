/*******************************************************************************
 * Licensed materials - Property of IBM
 * 6949-63D
 * Developed by Digital Integration Practice
 * (C) Copyright IBM Corp. 2016 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
 * This asset is provided ``as is'' and any expressed or implied warranties, including, but not limited to, the implied warranties and fitness 
 * for a particular purpose are disclaimed. in no event shall IBM be liable for any direct, indirect, incidental, special, 
 * exemplary, or consequential damages.
 * 
 *******************************************************************************/
package com.ibm.dip.microservice.framework.configuration;

import org.springframework.cloud.sleuth.sampler.AlwaysSampler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class AppConfig {

	@Bean
	public AlwaysSampler defaultSampler() {
	  return new AlwaysSampler();
	}
	
	// cross origin 
	// @Bean
	// public WebMvcConfigurer corsConfigurer()
	// {
	// 	return new WebMvcConfigurerAdapter()
	// 	{
	// 		@Override
	// 		public void addCorsMappings(CorsRegistry registry)
	// 		{
	// 			registry.addMapping("/**").allowedOrigins("*").allowedHeaders("*").allowedMethods("OPTIONS", "HEAD",
	// 					"GET", "PUT", "POST", "PATCH");
	// 		}
	// 	};
	// }
}
