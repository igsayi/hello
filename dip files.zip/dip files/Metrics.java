/*******************************************************************************
 * Licensed materials - Property of IBM
 * 6949-63D
 * Developed by Digital Integration Practice
 * (C) Copyright IBM Corp. 2016 All Rights Reserved.
 * 
 * US Government Users Restricted Rights - Use, duplication or disclosure restricted by GSA ADP Schedule Contract with IBM Corp. 
 * This asset is provided ``as is'' and any expressed or implied warranties, including, but not limited to, the implied warranties and fitness 
 * for a particular purpose are disclaimed. in no event shall IBM be liable for any direct, indirect, incidental, special, 
 * exemplary, or consequential damages.
 * 
 *******************************************************************************/
package com.ibm.dip.microservice.framework.configuration;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import io.prometheus.client.Collector;
import io.prometheus.client.Counter;
import io.prometheus.client.Gauge;
import io.prometheus.client.Histogram;
import io.prometheus.client.Summary;

@Component
@ConditionalOnProperty(name="metrics.enabled",  havingValue="true", matchIfMissing=false)
public final class Metrics {
	private static final Logger log = LoggerFactory.getLogger(Metrics.class);
	private static Map<String, Collector.Describable> metrics = null;
	private static boolean enabled = false;
	
	@Bean
	public static Object registerPrometheuesMetrics() throws Exception {
		metrics = new ConcurrentHashMap<String, Collector.Describable>();
		registerMetric();
		enabled = true;
		return metrics;
	}
	
	public static void updateCounter(String name) throws Exception {
		updateCounter(name, name);
	}
	
	public static void updateCounter(String name, String... labelValues) {
		if(enabled) {
			Collector.Describable obj = metrics.get(name);
			if(obj == null) {
				log.error("The metric details are not registered");
				return;
			}
			Counter c = (Counter)obj;
			c.labels(labelValues).inc();
		}
	}

	public static void updateGauge(String name, boolean inc) throws Exception {
		updateGauge(name, inc, name);
	}

	public static void updateGauge(String name, boolean inc, String... labelValues) {
		if(enabled) {
			Collector.Describable obj = metrics.get(name);
			if(obj == null) {
				log.error("The metric details are not registered");
				return;
			}
			Gauge g = (Gauge)obj;
			if(inc) {
				g.labels(labelValues).inc();
			} else {
				g.labels(labelValues).dec();
			}
		}
	}

	public static void updateSummary(String name, double amt) {
		updateSummary(name, amt, name);
	}
	
	public static void updateSummary(String name, double amt,  String... labelValues) {
		if(enabled) {
			Collector.Describable obj = metrics.get(name);
			if(obj == null) {
				log.error("The metric details are not registered");
				return;
			}
			Summary s = (Summary)obj;
			s.labels(labelValues).observe(amt);
		}
	}

	public static void updateHistogram(String name, double amt) throws Exception {
		updateHistogram(name, amt, name);
	}
	
	public static void updateHistogram(String name, double amt,  String... labelValues) {
		if(enabled) {
			Collector.Describable obj = metrics.get(name);
			if(obj == null) {
				log.error("The metric details are not registered");
				return;
			}
			Histogram s = (Histogram)obj;
			s.labels(labelValues).observe(amt);
		}
	}

	//--------------------------------- Utility methods ---------------------------
	
	public static void registerMetric() throws Exception {
		JSONObject jsonObject = readJson();
		JSONArray metrics = (JSONArray)jsonObject.get("metrics");

		if(metrics != null) {
			for(Object o: metrics) {
				JSONObject jObj = (JSONObject) o;
				String name = (String)jObj.get("name");
				String[] labelNames = ((String)jObj.get("label_names")).split(",");
				String helpText = (String)jObj.get("help_text");
				MetricType type = MetricType.fromValue((String)jObj.get("type"));
				register(name, helpText, labelNames, type);
			}
		}
	}

	public static void register(String name, String helpText, String[] labelNames, MetricType type) {
		switch(type) {
	        case COUNTER:
	        	final Counter c = Counter.build()
	    	    .name("counter__" + name)
	    	    .help(helpText)
	    	    .labelNames(labelNames)
	    	    .register();
	        	metrics.put(name, c);
	    	    break;
	        case GAUGE:
	        	final Gauge g = Gauge.build()
	    	    .name("guage_"+name)
	    	    .help(helpText)
	    	    .labelNames(labelNames)
	    	    .register();
	        	metrics.put(name, g);
	    	    break;
	        case SUMMARY:
	        	final Summary s = Summary.build()
	    	    .name("summary_"+name)
	    	    .help(helpText)
	    	    .labelNames(labelNames)
	    	    .register();
	        	metrics.put(name, s);
	        	break;
	        case HISTOGRAM:
	        	final Histogram h = Histogram.build()
	    	    .name("histogram_"+name)
	    	    .help(helpText)
	    	    .labelNames(labelNames)
	    	    .register();
	        	metrics.put(name, h);
	        	break;
		    default:
	    	    break;
		}
	}

	public static JSONObject readJson() throws IOException, ParseException, org.json.simple.parser.ParseException {
		JSONParser parser = new JSONParser();
		try {
			JSONObject jsonObject = (JSONObject)parser.parse(new FileReader("src/main/resources/metrics.json"));
			return jsonObject;
		} catch (FileNotFoundException fe) {
			throw new FileNotFoundException();
		}
	}

	//---------------------------------------------- ---------------------------
}
