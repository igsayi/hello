package com.standard.decisionservice.model;

import java.util.*;

import org.joda.time.DateTime;

import org.joda.time.*;

import java.math.*;

import org.springframework.web.multipart.MultipartFile;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class RetrieveDecisionsP {

	private String tpaId;

	private String requestId;

	private LocalDate startDate;

	private LocalDate endDate;

	private String originChannelId;

	private String originDeptId;

	private String originEmployeeId;

	private String originSourceId;

	private String originTerminalId;

	private String originUserId;

	private DateTime timeStamp;

	public RetrieveDecisionsP(){}

	public RetrieveDecisionsP(String tpaId,String requestId,LocalDate startDate,LocalDate endDate,String originChannelId,String originDeptId,String originEmployeeId,String originSourceId,String originTerminalId,String originUserId,DateTime timeStamp){
		 this.tpaId=tpaId;
		 this.requestId=requestId;
		 this.startDate=startDate;
		 this.endDate=endDate;
		 this.originChannelId=originChannelId;
		 this.originDeptId=originDeptId;
		 this.originEmployeeId=originEmployeeId;
		 this.originSourceId=originSourceId;
		 this.originTerminalId=originTerminalId;
		 this.originUserId=originUserId;
		 this.timeStamp=timeStamp;
	}


	public String getTpaId() {
		 return tpaId;
	}

	public void setTpaId(String tpaId) {
		 this.tpaId=tpaId;
	}
	public String getRequestId() {
		 return requestId;
	}

	public void setRequestId(String requestId) {
		 this.requestId=requestId;
	}
	public LocalDate getStartDate() {
		 return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		 this.startDate=startDate;
	}
	public LocalDate getEndDate() {
		 return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		 this.endDate=endDate;
	}
	public String getOriginChannelId() {
		 return originChannelId;
	}

	public void setOriginChannelId(String originChannelId) {
		 this.originChannelId=originChannelId;
	}
	public String getOriginDeptId() {
		 return originDeptId;
	}

	public void setOriginDeptId(String originDeptId) {
		 this.originDeptId=originDeptId;
	}
	public String getOriginEmployeeId() {
		 return originEmployeeId;
	}

	public void setOriginEmployeeId(String originEmployeeId) {
		 this.originEmployeeId=originEmployeeId;
	}
	public String getOriginSourceId() {
		 return originSourceId;
	}

	public void setOriginSourceId(String originSourceId) {
		 this.originSourceId=originSourceId;
	}
	public String getOriginTerminalId() {
		 return originTerminalId;
	}

	public void setOriginTerminalId(String originTerminalId) {
		 this.originTerminalId=originTerminalId;
	}
	public String getOriginUserId() {
		 return originUserId;
	}

	public void setOriginUserId(String originUserId) {
		 this.originUserId=originUserId;
	}
	public DateTime getTimeStamp() {
		 return timeStamp;
	}

	public void setTimeStamp(DateTime timeStamp) {
		 this.timeStamp=timeStamp;
	}
}