package com.standard.decisionservice.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.standard.decisionservice.model.RetrieveDecisionsP;
public interface ErrorReportingPersistance extends MongoRepository<RetrieveDecisionsP,String>{

}
