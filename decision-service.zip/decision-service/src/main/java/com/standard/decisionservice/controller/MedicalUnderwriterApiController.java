package com.standard.decisionservice.controller;
import org.springframework.beans.factory.annotation.Autowired;
import com.standard.decisionservice.services.*;
import com.standard.decisionservice.model.*;
import javax.servlet.http.HttpServletRequest;


import org.joda.time.DateTime;
import com.standard.decisionservice.model.ErrorResponseObject;
import org.joda.time.LocalDate;
import com.standard.decisionservice.model.RetrieveDecisionsResponse;

import io.swagger.annotations.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import javax.validation.constraints.*;
import javax.validation.Valid;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-31T15:56:15.320+05:30")

@Controller
public class MedicalUnderwriterApiController implements MedicalUnderwriterApi {
	@Autowired

	private HttpServletRequest request;

	@Autowired
	 private RetrieveDecisionsI retrieveDecisionsI;




    public ResponseEntity<RetrieveDecisionsResponse> retrieveDecisions(@ApiParam(value = "",required=true ) @PathVariable("tpaId") String tpaId,
        @ApiParam(value = "Global transaction Id" ,required=true) @RequestHeader(value="requestId", required=true) String requestId,
        @ApiParam(value = "") @RequestParam(value = "startDate", required = false) LocalDate startDate,
        @ApiParam(value = "") @RequestParam(value = "endDate", required = false) LocalDate endDate,
        @ApiParam(value = "ID of the channel from which the invocation occurred" ) @RequestHeader(value="originChannelId", required=false) String originChannelId,
        @ApiParam(value = "ID of the department from which the invocation occurred" ) @RequestHeader(value="originDeptId", required=false) String originDeptId,
        @ApiParam(value = "Employee ID of the requester (as per employee HR record)" ) @RequestHeader(value="originEmployeeId", required=false) String originEmployeeId,
        @ApiParam(value = "ID of the source system invoking" ) @RequestHeader(value="originSourceId", required=false) String originSourceId,
        @ApiParam(value = "Terminal ID of the requester" ) @RequestHeader(value="originTerminalId", required=false) String originTerminalId,
        @ApiParam(value = "User ID of the requester (as per LDAP)" ) @RequestHeader(value="originUserId", required=false) String originUserId,
        @ApiParam(value = "The time stamp when the request was sent to system" ) @RequestHeader(value="timeStamp", required=false) DateTime timeStamp) {

	request.setAttribute("operationId","retrieveDecisions");
	RetrieveDecisionsResponseWrapper res = retrieveDecisionsI.execute(new RetrieveDecisionsP(tpaId,requestId,startDate,endDate,originChannelId,originDeptId,originEmployeeId,originSourceId,originTerminalId,originUserId,timeStamp));
        return new ResponseEntity<RetrieveDecisionsResponse>(res.getResponse(),res.getHeaders(),HttpStatus.OK);
    }

}
