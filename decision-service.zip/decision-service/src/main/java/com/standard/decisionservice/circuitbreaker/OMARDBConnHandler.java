package com.standard.decisionservice.circuitbreaker;

import com.mysql.jdbc.Connection;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.standard.decisionservice.model.RetrieveDecisionsP;


public class OMARDBConnHandler {
	
	@HystrixCommand(fallbackMethod = "reliable")
	public Connection getDatabaseConnection(RetrieveDecisionsP pojo){
		return null;
		//TODO
		
	}
	
	public Connection reliable(RetrieveDecisionsP pojo){
		//TODO
		return null;
	}
}
