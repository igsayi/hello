package com.standard.decisionservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractDetails
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-31T15:56:15.320+05:30")

public class ContractDetails   {
  @JsonProperty("tpaId")
  private String tpaId = null;

  @JsonProperty("tpaName")
  private String tpaName = null;

  @JsonProperty("groupId")
  private String groupId = null;

  @JsonProperty("groupName")
  private String groupName = null;

  @JsonProperty("companyId")
  private String companyId = null;

  @JsonProperty("featureId")
  private String featureId = null;

  @JsonProperty("contractId")
  private String contractId = null;

  public ContractDetails tpaId(String tpaId) {
    this.tpaId = tpaId;
    return this;
  }

   /**
   * Get tpaId
   * @return tpaId
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getTpaId() {
    return tpaId;
  }

  public void setTpaId(String tpaId) {
    this.tpaId = tpaId;
  }

  public ContractDetails tpaName(String tpaName) {
    this.tpaName = tpaName;
    return this;
  }

   /**
   * Get tpaName
   * @return tpaName
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getTpaName() {
    return tpaName;
  }

  public void setTpaName(String tpaName) {
    this.tpaName = tpaName;
  }

  public ContractDetails groupId(String groupId) {
    this.groupId = groupId;
    return this;
  }

   /**
   * Get groupId
   * @return groupId
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getGroupId() {
    return groupId;
  }

  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }

  public ContractDetails groupName(String groupName) {
    this.groupName = groupName;
    return this;
  }

   /**
   * Get groupName
   * @return groupName
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getGroupName() {
    return groupName;
  }

  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }

  public ContractDetails companyId(String companyId) {
    this.companyId = companyId;
    return this;
  }

   /**
   * Required by EAI to enable them to find the external Service Provider(s) in GAC. Features are associated to Contracts. Some Features also have Service Providers associated to them. COMPANY_ID =  NM is out-of-scope. Default values: SI,YI and NM
   * @return companyId
  **/
  @ApiModelProperty(required = true, value = "Required by EAI to enable them to find the external Service Provider(s) in GAC. Features are associated to Contracts. Some Features also have Service Providers associated to them. COMPANY_ID =  NM is out-of-scope. Default values: SI,YI and NM")
  @NotNull


  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public ContractDetails featureId(String featureId) {
    this.featureId = featureId;
    return this;
  }

   /**
   * FeatureId is related to contract. Default values:ENST,ENMT 
   * @return featureId
  **/
  @ApiModelProperty(value = "FeatureId is related to contract. Default values:ENST,ENMT ")


  public String getFeatureId() {
    return featureId;
  }

  public void setFeatureId(String featureId) {
    this.featureId = featureId;
  }

  public ContractDetails contractId(String contractId) {
    this.contractId = contractId;
    return this;
  }

   /**
   * Get contractId
   * @return contractId
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getContractId() {
    return contractId;
  }

  public void setContractId(String contractId) {
    this.contractId = contractId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractDetails contractDetails = (ContractDetails) o;
    return Objects.equals(this.tpaId, contractDetails.tpaId) &&
        Objects.equals(this.tpaName, contractDetails.tpaName) &&
        Objects.equals(this.groupId, contractDetails.groupId) &&
        Objects.equals(this.groupName, contractDetails.groupName) &&
        Objects.equals(this.companyId, contractDetails.companyId) &&
        Objects.equals(this.featureId, contractDetails.featureId) &&
        Objects.equals(this.contractId, contractDetails.contractId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tpaId, tpaName, groupId, groupName, companyId, featureId, contractId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractDetails {\n");
    
    sb.append("    tpaId: ").append(toIndentedString(tpaId)).append("\n");
    sb.append("    tpaName: ").append(toIndentedString(tpaName)).append("\n");
    sb.append("    groupId: ").append(toIndentedString(groupId)).append("\n");
    sb.append("    groupName: ").append(toIndentedString(groupName)).append("\n");
    sb.append("    companyId: ").append(toIndentedString(companyId)).append("\n");
    sb.append("    featureId: ").append(toIndentedString(featureId)).append("\n");
    sb.append("    contractId: ").append(toIndentedString(contractId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

