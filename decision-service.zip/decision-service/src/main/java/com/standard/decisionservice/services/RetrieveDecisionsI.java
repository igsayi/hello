package com.standard.decisionservice.services;

import java.util.*;

import com.standard.decisionservice.model.*;

public interface RetrieveDecisionsI {

	public RetrieveDecisionsResponseWrapper execute(RetrieveDecisionsP pojo);
	public <T> T error(int statusCode,Class<T> type,Exception exception) throws InstantiationException, IllegalAccessException;

}