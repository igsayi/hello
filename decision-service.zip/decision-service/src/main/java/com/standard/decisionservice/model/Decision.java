package com.standard.decisionservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.standard.decisionservice.model.ContractDetails;
import com.standard.decisionservice.model.IndividualDetails;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import org.joda.time.LocalDate;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Decision
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-08-31T15:56:15.320+05:30")

public class Decision   {
  @JsonProperty("decisionId")
  private String decisionId = null;

  /**
   * The message type is required by EAI Services.
   */
  public enum MessageTypeEnum {
    UNDERWRITING_DECISION("Medical Underwriting Decision"),
    
    HISTORY_STATEMENT("Medical History Statement");

    private String value;

    MessageTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static MessageTypeEnum fromValue(String text) {
      for (MessageTypeEnum b : MessageTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("messageType")
  private MessageTypeEnum messageType = null;

  @JsonProperty("contractDetails")
  private ContractDetails contractDetails = null;

  @JsonProperty("MemberDetails")
  private IndividualDetails memberDetails = null;

  @JsonProperty("ApplicantDetails")
  private IndividualDetails applicantDetails = null;

  /**
   * Indicate the relation between the Applicant and the Member. 
   */
  public enum RelationshipEnum {
    MEMBER("Member"),
    
    CHILD("Child"),
    
    SPOUSE("Spouse"),
    
    PARTNER_DOMESTIC_("Partner (domestic)"),
    
    UNKNOWN("Unknown");

    private String value;

    RelationshipEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static RelationshipEnum fromValue(String text) {
      for (RelationshipEnum b : RelationshipEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("relationship")
  private RelationshipEnum relationship = null;

  /**
   * Medical Underwriters decision regarding an Applicant's request for additional coverage
   */
  public enum DecisionStatusEnum {
    APPROVED("APPROVED"),
    
    DECLINED("DECLINED"),
    
    LOI("LOI"),
    
    NONE("NONE");

    private String value;

    DecisionStatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static DecisionStatusEnum fromValue(String text) {
      for (DecisionStatusEnum b : DecisionStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("decisionStatus")
  private DecisionStatusEnum decisionStatus = null;

  @JsonProperty("decisionDate")
  private LocalDate decisionDate = null;

  @JsonProperty("completeDate")
  private LocalDate completeDate = null;

  @JsonProperty("overGuranteeIssueBenefitAmount")
  private BigDecimal overGuranteeIssueBenefitAmount = null;

  @JsonProperty("benefitAmountText")
  private String benefitAmountText = null;

  @JsonProperty("guranteeIssueAmount")
  private BigDecimal guranteeIssueAmount = null;

  @JsonProperty("totalQualifiedBenefitAmount")
  private BigDecimal totalQualifiedBenefitAmount = null;

  @JsonProperty("productId")
  private String productId = null;

  public Decision decisionId(String decisionId) {
    this.decisionId = decisionId;
    return this;
  }

   /**
   * unique id
   * @return decisionId
  **/
  @ApiModelProperty(required = true, value = "unique id")
  @NotNull


  public String getDecisionId() {
    return decisionId;
  }

  public void setDecisionId(String decisionId) {
    this.decisionId = decisionId;
  }

  public Decision messageType(MessageTypeEnum messageType) {
    this.messageType = messageType;
    return this;
  }

   /**
   * The message type is required by EAI Services.
   * @return messageType
  **/
  @ApiModelProperty(required = true, value = "The message type is required by EAI Services.")
  @NotNull


  public MessageTypeEnum getMessageType() {
    return messageType;
  }

  public void setMessageType(MessageTypeEnum messageType) {
    this.messageType = messageType;
  }

  public Decision contractDetails(ContractDetails contractDetails) {
    this.contractDetails = contractDetails;
    return this;
  }

   /**
   * Get contractDetails
   * @return contractDetails
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public ContractDetails getContractDetails() {
    return contractDetails;
  }

  public void setContractDetails(ContractDetails contractDetails) {
    this.contractDetails = contractDetails;
  }

  public Decision memberDetails(IndividualDetails memberDetails) {
    this.memberDetails = memberDetails;
    return this;
  }

   /**
   * Get memberDetails
   * @return memberDetails
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public IndividualDetails getMemberDetails() {
    return memberDetails;
  }

  public void setMemberDetails(IndividualDetails memberDetails) {
    this.memberDetails = memberDetails;
  }

  public Decision applicantDetails(IndividualDetails applicantDetails) {
    this.applicantDetails = applicantDetails;
    return this;
  }

   /**
   * Get applicantDetails
   * @return applicantDetails
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public IndividualDetails getApplicantDetails() {
    return applicantDetails;
  }

  public void setApplicantDetails(IndividualDetails applicantDetails) {
    this.applicantDetails = applicantDetails;
  }

  public Decision relationship(RelationshipEnum relationship) {
    this.relationship = relationship;
    return this;
  }

   /**
   * Indicate the relation between the Applicant and the Member. 
   * @return relationship
  **/
  @ApiModelProperty(value = "Indicate the relation between the Applicant and the Member. ")


  public RelationshipEnum getRelationship() {
    return relationship;
  }

  public void setRelationship(RelationshipEnum relationship) {
    this.relationship = relationship;
  }

  public Decision decisionStatus(DecisionStatusEnum decisionStatus) {
    this.decisionStatus = decisionStatus;
    return this;
  }

   /**
   * Medical Underwriters decision regarding an Applicant's request for additional coverage
   * @return decisionStatus
  **/
  @ApiModelProperty(required = true, value = "Medical Underwriters decision regarding an Applicant's request for additional coverage")
  @NotNull


  public DecisionStatusEnum getDecisionStatus() {
    return decisionStatus;
  }

  public void setDecisionStatus(DecisionStatusEnum decisionStatus) {
    this.decisionStatus = decisionStatus;
  }

  public Decision decisionDate(LocalDate decisionDate) {
    this.decisionDate = decisionDate;
    return this;
  }

   /**
   * Indicates the date the decision was entered into OMAR by Medical Underwriter.
   * @return decisionDate
  **/
  @ApiModelProperty(required = true, value = "Indicates the date the decision was entered into OMAR by Medical Underwriter.")
  @NotNull

  @Valid

  public LocalDate getDecisionDate() {
    return decisionDate;
  }

  public void setDecisionDate(LocalDate decisionDate) {
    this.decisionDate = decisionDate;
  }

  public Decision completeDate(LocalDate completeDate) {
    this.completeDate = completeDate;
    return this;
  }

   /**
   * Get completeDate
   * @return completeDate
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public LocalDate getCompleteDate() {
    return completeDate;
  }

  public void setCompleteDate(LocalDate completeDate) {
    this.completeDate = completeDate;
  }

  public Decision overGuranteeIssueBenefitAmount(BigDecimal overGuranteeIssueBenefitAmount) {
    this.overGuranteeIssueBenefitAmount = overGuranteeIssueBenefitAmount;
    return this;
  }

   /**
   * The benefit amount requested by the Applicant above the guarantee issue amount.
   * @return overGuranteeIssueBenefitAmount
  **/
  @ApiModelProperty(required = true, value = "The benefit amount requested by the Applicant above the guarantee issue amount.")
  @NotNull

  @Valid

  public BigDecimal getOverGuranteeIssueBenefitAmount() {
    return overGuranteeIssueBenefitAmount;
  }

  public void setOverGuranteeIssueBenefitAmount(BigDecimal overGuranteeIssueBenefitAmount) {
    this.overGuranteeIssueBenefitAmount = overGuranteeIssueBenefitAmount;
  }

  public Decision benefitAmountText(String benefitAmountText) {
    this.benefitAmountText = benefitAmountText;
    return this;
  }

   /**
   * A text description of the benefit amount the Applicant has requested beyond the Guarantee Issue amount of the policy in which evidence of insurability is required.  This will be a text field to account for earnings based and/or flat benefit amounts.  For example, Earnings Based Flat Amount - 100,000
   * @return benefitAmountText
  **/
  @ApiModelProperty(required = true, value = "A text description of the benefit amount the Applicant has requested beyond the Guarantee Issue amount of the policy in which evidence of insurability is required.  This will be a text field to account for earnings based and/or flat benefit amounts.  For example, Earnings Based Flat Amount - 100,000")
  @NotNull


  public String getBenefitAmountText() {
    return benefitAmountText;
  }

  public void setBenefitAmountText(String benefitAmountText) {
    this.benefitAmountText = benefitAmountText;
  }

  public Decision guranteeIssueAmount(BigDecimal guranteeIssueAmount) {
    this.guranteeIssueAmount = guranteeIssueAmount;
    return this;
  }

   /**
   * The benefit amount available to the insured person as written in the contract. No EOI is required to receive this 
   * @return guranteeIssueAmount
  **/
  @ApiModelProperty(required = true, value = "The benefit amount available to the insured person as written in the contract. No EOI is required to receive this ")
  @NotNull

  @Valid

  public BigDecimal getGuranteeIssueAmount() {
    return guranteeIssueAmount;
  }

  public void setGuranteeIssueAmount(BigDecimal guranteeIssueAmount) {
    this.guranteeIssueAmount = guranteeIssueAmount;
  }

  public Decision totalQualifiedBenefitAmount(BigDecimal totalQualifiedBenefitAmount) {
    this.totalQualifiedBenefitAmount = totalQualifiedBenefitAmount;
    return this;
  }

   /**
   * The sum of the Guarantee Issue Amount plus the Over Guarantee Issue Benefit Amount. 
   * @return totalQualifiedBenefitAmount
  **/
  @ApiModelProperty(required = true, value = "The sum of the Guarantee Issue Amount plus the Over Guarantee Issue Benefit Amount. ")
  @NotNull

  @Valid

  public BigDecimal getTotalQualifiedBenefitAmount() {
    return totalQualifiedBenefitAmount;
  }

  public void setTotalQualifiedBenefitAmount(BigDecimal totalQualifiedBenefitAmount) {
    this.totalQualifiedBenefitAmount = totalQualifiedBenefitAmount;
  }

  public Decision productId(String productId) {
    this.productId = productId;
    return this;
  }

   /**
   * ProductId is the coverage type. The value should be between these codes(BL,AL,ACL,ASL,DL,XCL,XDL,XSL,SL,VF,LT,BLT,VL,ST,BST,LS,SDL,TLT,TS,TST,SS,SD)
   * @return productId
  **/
  @ApiModelProperty(required = true, value = "ProductId is the coverage type. The value should be between these codes(BL,AL,ACL,ASL,DL,XCL,XDL,XSL,SL,VF,LT,BLT,VL,ST,BST,LS,SDL,TLT,TS,TST,SS,SD)")
  @NotNull


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Decision decision = (Decision) o;
    return Objects.equals(this.decisionId, decision.decisionId) &&
        Objects.equals(this.messageType, decision.messageType) &&
        Objects.equals(this.contractDetails, decision.contractDetails) &&
        Objects.equals(this.memberDetails, decision.memberDetails) &&
        Objects.equals(this.applicantDetails, decision.applicantDetails) &&
        Objects.equals(this.relationship, decision.relationship) &&
        Objects.equals(this.decisionStatus, decision.decisionStatus) &&
        Objects.equals(this.decisionDate, decision.decisionDate) &&
        Objects.equals(this.completeDate, decision.completeDate) &&
        Objects.equals(this.overGuranteeIssueBenefitAmount, decision.overGuranteeIssueBenefitAmount) &&
        Objects.equals(this.benefitAmountText, decision.benefitAmountText) &&
        Objects.equals(this.guranteeIssueAmount, decision.guranteeIssueAmount) &&
        Objects.equals(this.totalQualifiedBenefitAmount, decision.totalQualifiedBenefitAmount) &&
        Objects.equals(this.productId, decision.productId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(decisionId, messageType, contractDetails, memberDetails, applicantDetails, relationship, decisionStatus, decisionDate, completeDate, overGuranteeIssueBenefitAmount, benefitAmountText, guranteeIssueAmount, totalQualifiedBenefitAmount, productId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Decision {\n");
    
    sb.append("    decisionId: ").append(toIndentedString(decisionId)).append("\n");
    sb.append("    messageType: ").append(toIndentedString(messageType)).append("\n");
    sb.append("    contractDetails: ").append(toIndentedString(contractDetails)).append("\n");
    sb.append("    memberDetails: ").append(toIndentedString(memberDetails)).append("\n");
    sb.append("    applicantDetails: ").append(toIndentedString(applicantDetails)).append("\n");
    sb.append("    relationship: ").append(toIndentedString(relationship)).append("\n");
    sb.append("    decisionStatus: ").append(toIndentedString(decisionStatus)).append("\n");
    sb.append("    decisionDate: ").append(toIndentedString(decisionDate)).append("\n");
    sb.append("    completeDate: ").append(toIndentedString(completeDate)).append("\n");
    sb.append("    overGuranteeIssueBenefitAmount: ").append(toIndentedString(overGuranteeIssueBenefitAmount)).append("\n");
    sb.append("    benefitAmountText: ").append(toIndentedString(benefitAmountText)).append("\n");
    sb.append("    guranteeIssueAmount: ").append(toIndentedString(guranteeIssueAmount)).append("\n");
    sb.append("    totalQualifiedBenefitAmount: ").append(toIndentedString(totalQualifiedBenefitAmount)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

