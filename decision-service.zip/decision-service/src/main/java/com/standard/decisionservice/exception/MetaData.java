package com.standard.decisionservice.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.standard.decisionservice.exception.ApiExceptionResponse;
import com.standard.decisionservice.exception.ErrorStatusCode;
import com.standard.decisionservice.model.*;

public class MetaData {

	public final static Map<String,Map<ErrorStatusCode, ApiExceptionResponse>> apiExceptions;
	
	static {		
		apiExceptions = new HashMap<String,Map<ErrorStatusCode, ApiExceptionResponse>>();

		Map<ErrorStatusCode, ApiExceptionResponse> responses; 
		try {
			
		 responses = new HashMap<ErrorStatusCode, ApiExceptionResponse>();
		 responses.put(ErrorStatusCode.getStatusCode(400),ApiExceptionResponse.getInstance(400,ErrorResponseObject.class,"Bad Request"));
		 responses.put(ErrorStatusCode.getStatusCode(401),ApiExceptionResponse.getInstance(401,ErrorResponseObject.class,"Unauthorized"));
		 responses.put(ErrorStatusCode.getStatusCode(403),ApiExceptionResponse.getInstance(403,ErrorResponseObject.class,"Forbidden"));
		 responses.put(ErrorStatusCode.getStatusCode(404),ApiExceptionResponse.getInstance(404,ErrorResponseObject.class,"API URL Not Found"));
		 responses.put(ErrorStatusCode.getStatusCode(405),ApiExceptionResponse.getInstance(405,ErrorResponseObject.class,"Method not Found"));
		 responses.put(ErrorStatusCode.getStatusCode(406),ApiExceptionResponse.getInstance(406,ErrorResponseObject.class,"Not Acceptable"));
		 responses.put(ErrorStatusCode.getStatusCode(429),ApiExceptionResponse.getInstance(429,ErrorResponseObject.class,"Too many Requests"));
		 responses.put(ErrorStatusCode.getStatusCode(500),ApiExceptionResponse.getInstance(500,ErrorResponseObject.class,"Internal Server Error"));
		 responses.put(ErrorStatusCode.getStatusCode(503),ApiExceptionResponse.getInstance(503,ErrorResponseObject.class,"Service Unavailable"));

		 apiExceptions.put("retrieveDecisions",responses);

		
		} catch (Exception e) {			
			e.printStackTrace();
		}
	}
}
