package com.standard.decisionservice.services.impl;

import java.util.*;

import com.standard.decisionservice.model.*;

import com.standard.decisionservice.dao.*;
import com.standard.decisionservice.services.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
@Service
public class RetrieveDecisionsImpl implements RetrieveDecisionsI {

	@Override

	public RetrieveDecisionsResponseWrapper execute(RetrieveDecisionsP pojo){
		//TODO
		return new RetrieveDecisionsResponseWrapper();
	}

	
	@Override
	public <T> T error(int statusCode, Class<T> type,Exception exception)
			throws InstantiationException, IllegalAccessException {
		//TODO to write error response
		return type.newInstance();
	}}